package com.mobdeve.s12.group4.mco

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class UserLogIn : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_log_in)

        val btnLogIn: Button = findViewById(R.id.btnLogin)
        val btnSignUp: Button = findViewById(R.id.btnSignUp)
        val editTextUsername: EditText = findViewById(R.id.editTextUsername)
        val editTextPassword: EditText = findViewById(R.id.editTextPassword)

        // Check if user is already logged in (you can store this info in SharedPreferences)
        if (isUserLoggedIn()) {
            navigateToMainActivity()
        }

        // Log in button click event
        btnLogIn.setOnClickListener {
            val username = editTextUsername.text.toString()
            val password = editTextPassword.text.toString()

            // Here you should add your login validation logic
            if (isValidLogin(username, password)) {
                navigateToMainActivity()
            } else {
                Toast.makeText(this, "Invalid login credentials", Toast.LENGTH_SHORT).show()
            }
        }

        // Sign up button click event
        btnSignUp.setOnClickListener {
            // Redirect to SignUp activity
            val intent = Intent(this, UserSignUp::class.java)
            startActivity(intent)
        }
    }

    // Placeholder function to simulate checking if the user is logged in
    private fun isUserLoggedIn(): Boolean {
        // Replace with your logic, such as checking SharedPreferences or a session
        return false
    }

    // Placeholder function to simulate login validation
    private fun isValidLogin(username: String, password: String): Boolean {
        return username == "admin" && password == "password" // Dummy validation
    }

    // Navigate to MainActivity
    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Prevent going back to login screen
    }
}
