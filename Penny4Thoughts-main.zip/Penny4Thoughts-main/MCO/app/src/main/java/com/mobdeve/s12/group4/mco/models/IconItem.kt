package com.mobdeve.s12.group4.mco.models

class IconItem(imageID: Int, bgColor: String) {
    var imageID = imageID
        private set
    var bgColor = bgColor
        private set

    var isSelected = false;
}