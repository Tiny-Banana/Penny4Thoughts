package com.mobdeve.s12.group4.mco.fragments

import androidx.fragment.app.Fragment
import com.mobdeve.s12.group4.mco.R

class RecordsFragment : Fragment(R.layout.records_fragment) {
}