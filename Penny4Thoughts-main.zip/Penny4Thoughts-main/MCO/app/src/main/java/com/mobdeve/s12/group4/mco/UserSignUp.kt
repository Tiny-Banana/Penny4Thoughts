package com.mobdeve.s12.group4.mco

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class UserSignUp : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.user_sign_up)

        val btnRegister = findViewById<Button>(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val username = findViewById<EditText>(R.id.etNewUsername).text.toString()
            val password = findViewById<EditText>(R.id.etNewPassword).text.toString()

            if (username.isNotEmpty() && password.isNotEmpty()) {
                // Simulate successful registration
                Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show()
                finish() // Go back to the login screen
            } else {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
