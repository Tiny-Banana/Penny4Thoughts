package com.mobdeve.s12.group4.mco

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.GravityCompat
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.appcompat.widget.Toolbar
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.mobdeve.s12.group4.mco.adapters.AccountAdapter
import com.mobdeve.s12.group4.mco.adapters.IconAdapter
import com.mobdeve.s12.group4.mco.fragments.HomeFragment
import com.mobdeve.s12.group4.mco.fragments.RecordsFragment
import com.mobdeve.s12.group4.mco.models.Account

class MainActivity : AppCompatActivity() {
    private lateinit var bottomNavigationView: BottomNavigationView
    private lateinit var toggle: ActionBarDrawerToggle
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toolbar: Toolbar
    private lateinit var addBtn: FloatingActionButton
    private lateinit var popupManager: PopupManager
    private lateinit var accountAdapter: AccountAdapter
    private lateinit var iconAdapter: IconAdapter
    private lateinit var drawerView: NavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize UI components
        bottomNavigationView = findViewById(R.id.bottomNavigationView)
        drawerLayout = findViewById(R.id.drawerLayout)
        toolbar = findViewById(R.id.toolbar)
        addBtn = findViewById(R.id.addBtn)
        drawerView = findViewById(R.id.drawerView)

        setSupportActionBar(toolbar)

        val accounts = DataGenerator.generateAccountData()
        val icons = DataGenerator.generateIcons()
        accountAdapter = AccountAdapter(accounts)
        iconAdapter = IconAdapter(icons)

        val homeFragment = HomeFragment(accountAdapter)
        val recordsFragment = RecordsFragment()

        setCurrentFragment(homeFragment)

        // Handle bottom navigation item selection
        bottomNavigationView.setOnItemSelectedListener {
            when (it.itemId) {
                R.id.home -> setCurrentFragment(homeFragment)
                R.id.record -> setCurrentFragment(recordsFragment)
            }
            true
        }

        popupManager = PopupManager(this, accountAdapter, iconAdapter)
        addBtn.setOnClickListener {
            showAddPopUp(it)
        }

        setSupportActionBar(toolbar)

        // Set up ActionBarDrawerToggle
        toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Handle click events for the navigation menu
        drawerView.setNavigationItemSelectedListener {
            when (it.itemId) {
                R.id.miFAQ -> {
                    Log.d("MainActivity", "FAQ clicked")
                    val intent = Intent(this, FAQActivity::class.java)
                    startActivity(intent)
                    drawerLayout.closeDrawers()
                    true
                }
                R.id.miProfile -> {
                    Log.d("MainActivity", "Profile clicked")
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    drawerLayout.closeDrawers()
                    true
                }
                else -> false
            }
        }
    }

    private fun showAddPopUp(view: View) {
        // Create a PopupMenu
        val popupMenu = PopupMenu(this, view)

        // Inflate the menu resource into the popup menu
        popupMenu.menuInflater.inflate(R.menu.popup_menu, popupMenu.menu)

        popupMenu.gravity = Gravity.END
        // Set click listeners for the popup menu items
        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.add_new_account -> {
                    Toast.makeText(this, "Add New Account clicked", Toast.LENGTH_SHORT).show()
                    popupManager.showNewAccPopUp()
                    true
                }
                R.id.add_transaction -> {
                    Toast.makeText(this, "Add Transaction clicked", Toast.LENGTH_SHORT).show()
                    true
                }
                else -> false
            }
        }

        // Show the popup menu
        popupMenu.show()
    }

    private fun setCurrentFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment, fragment)
            commit()
        }
    }
}