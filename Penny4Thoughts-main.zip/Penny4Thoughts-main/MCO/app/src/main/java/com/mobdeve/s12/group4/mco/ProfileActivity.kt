package com.mobdeve.s12.group4.mco

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.mobdeve.s12.group4.mco.R

class ProfileActivity : AppCompatActivity() {

    private lateinit var tvUserName: TextView
    private lateinit var tvUserHandle: TextView
    private lateinit var etNewName: EditText
    private lateinit var etNewEmail: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var btnCancel: Button
    private lateinit var btnSave: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.act_profilemanagement)

        tvUserName = findViewById(R.id.tvUserName)
        tvUserHandle = findViewById(R.id.tvUserHandle)
        etNewName = findViewById(R.id.etNewName)
        etNewEmail = findViewById(R.id.etNewEmail)
        etNewPassword = findViewById(R.id.etNewPassword)
        btnCancel = findViewById(R.id.btnCancel)
        btnSave = findViewById(R.id.btnSave)

        tvUserName.text = "Admin"
        tvUserHandle.text = "@admin"

        btnCancel.setOnClickListener {
            onBackPressed()
        }

        btnSave.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }
    }
}
